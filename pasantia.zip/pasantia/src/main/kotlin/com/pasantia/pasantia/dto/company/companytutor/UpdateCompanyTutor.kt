package com.pasantia.pasantia.dto.company.companytutor


data class UpdateCompanyTutorDTO(
    val phone: String?
)
