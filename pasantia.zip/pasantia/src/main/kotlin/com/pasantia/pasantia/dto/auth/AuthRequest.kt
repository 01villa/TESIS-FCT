package com.pasantia.pasantia.dto.auth

data class AuthRequest(
    val email: String,
    val password: String
)