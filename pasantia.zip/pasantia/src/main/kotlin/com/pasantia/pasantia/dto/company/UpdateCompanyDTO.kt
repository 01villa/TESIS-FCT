package com.pasantia.pasantia.dto.company

data class UpdateCompanyDTO(
    val name: String?,
    val address: String?
)
