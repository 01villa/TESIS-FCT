package com.pasantia.pasantia.services

import com.pasantia.pasantia.dto.admin.CreateAdminForEntityDTO
import com.pasantia.pasantia.dto.company.companyadmin.CompanyAdminDTO
import com.pasantia.pasantia.entities.CompanyAdmin
import com.pasantia.pasantia.entities.User
import com.pasantia.pasantia.entities.UserRole
import com.pasantia.pasantia.entities.UserRoleId
import com.pasantia.pasantia.mappers.CompanyAdminMapper
import com.pasantia.pasantia.repositories.*
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.time.LocalDateTime
import java.util.*


@Service
class CompanyAdminService(
    private val companyAdminRepository: CompanyAdminRepository,
    private val companyRepository: CompanyRepository,
    private val userRepository: UserRepository,
    private val passwordEncoder: PasswordEncoder,
    private val roleRepository: RoleRepository,
    private val userRoleRepository: UserRoleRepository
) {

    fun list(): List<CompanyAdminDTO> =
        companyAdminRepository.findAllByActiveTrue()
            .map { CompanyAdminMapper.toDTO(it) }

    fun listByCompany(companyId: UUID): List<CompanyAdminDTO> =
        companyAdminRepository.findAllByCompanyIdAndActiveTrue(companyId)
            .map { CompanyAdminMapper.toDTO(it) }

    fun get(id: UUID): CompanyAdminDTO {
        val admin = companyAdminRepository.findByIdAndActiveTrue(id)
            ?: throw IllegalArgumentException("CompanyAdmin not found or inactive")

        return CompanyAdminMapper.toDTO(admin)
    }

    fun softDelete(id: UUID) {
        val admin = companyAdminRepository.findByIdAndActiveTrue(id)
            ?: throw IllegalArgumentException("CompanyAdmin not found or already inactive")

        admin.active = false
        admin.deletedAt = LocalDateTime.now()
        companyAdminRepository.save(admin)
    }

    fun restore(id: UUID) {
        val admin = companyAdminRepository.findById(id)
            .orElseThrow { IllegalArgumentException("CompanyAdmin not found") }

        admin.active = true
        admin.deletedAt = null
        companyAdminRepository.save(admin)
    }

    @Transactional
    fun createCompanyAdmin(companyId: UUID, dto: CreateAdminForEntityDTO): CompanyAdminDTO {

        val company = companyRepository.findById(companyId)
            .orElseThrow { IllegalArgumentException("Company not found: $companyId") }

        if (userRepository.findByEmail(dto.email) != null)
            throw IllegalArgumentException("Email already exists: ${dto.email}")

        val user = User(
            email = dto.email,
            fullName = dto.fullName,
            passwordHash = passwordEncoder.encode(dto.password),
            active = true
        )
        val savedUser = userRepository.save(user)

        val role = roleRepository.findByName("COMPANY_ADMIN")
            ?: throw IllegalArgumentException("Role COMPANY_ADMIN not found")

        // ✔ Tu estructura exacta con UserRoleId
        val userRoleId = UserRoleId(savedUser.id!!, role.id!!)
        val userRole = UserRole(userRoleId, savedUser, role)
        userRoleRepository.save(userRole)

        val companyAdmin = CompanyAdmin(
            user = savedUser,
            company = company,
            active = true
        )

        val savedAdmin = companyAdminRepository.save(companyAdmin)

        return CompanyAdminMapper.toDTO(savedAdmin)
    }
}
