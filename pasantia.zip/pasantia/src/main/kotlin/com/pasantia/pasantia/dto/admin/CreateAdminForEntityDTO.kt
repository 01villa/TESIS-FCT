package com.pasantia.pasantia.dto.admin

data class CreateAdminForEntityDTO(
    val email: String,
    val fullName: String,
    val password: String
)
