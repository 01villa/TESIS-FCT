package com.pasantia.pasantia.dto.school

data class UpdateSchoolDTO(
    val name: String?,
    val address: String?
)
