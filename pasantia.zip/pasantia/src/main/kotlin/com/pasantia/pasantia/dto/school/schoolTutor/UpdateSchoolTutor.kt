package com.pasantia.pasantia.dto.school.schoolTutor

data class UpdateSchoolTutorDTO(
    val phone: String?
)
