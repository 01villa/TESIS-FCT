package com.pasantia.pasantia.dto.admin

data class CreateCompanyDTO(
    val name: String,
    val address: String?
)
