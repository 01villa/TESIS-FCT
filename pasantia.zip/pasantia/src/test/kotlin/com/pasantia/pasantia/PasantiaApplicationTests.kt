package com.pasantia.pasantia

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PasantiaApplicationTests {

	@Test
	fun contextLoads() {
	}

}
